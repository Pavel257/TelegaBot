TOKEN = "2116946135:AAEDNdXJ2UtmEK8ZtwW1_JeiDfVdveEiNi8"
keys = {'доллар': 'USD',
        'евро': 'EUR',
        'биткоин': 'BTC',
        'эфириум': 'ETH',
        'рубль': 'RUB'
        }