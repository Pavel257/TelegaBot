import telebot
from config import *
from TelegaUtils import ConvertionException, CryptoConverter

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message: telebot.types.Message):
    text = "Чтобы начать работу, введите команду боту (с маленькой буквы) в следующем формате: \
           \n<название валюты><в какую валюту перевести><количество переводимой валюты> \nПример: доллар рубль 1 " \
           "\n(переведёт 1 доллар в рубли) \nКоманда /values покажет список доступных валют."
    bot.reply_to(message, text)


@bot.message_handler(commands=['values'])
def values(message: telebot.types.Message):
    text = 'Доступные валюты:'
    for key in keys.keys():
        text = '\n'.join((text, key,))
    bot.reply_to(message, text)


@bot.message_handler(content_types=['text'])
def text_handler(message):
    text = message.text.lower()
    chat_id = message.chat.id
    if text == "привет":
        bot.send_message(chat_id, 'Привет, я бот конвертор валют.\nДля начала работы нажмите команду /start')
    else:
        return convert(message)


@bot.message_handler(content_types=['text'])
def convert(message: telebot.types.Message):
    try:
        values = message.text.split()

        if len(values) > 3:
            raise ConvertionException('Слишком много параметров или параметры введены неверно.\n'
                                      'Чтобы узнать правильные параметры ввода нажмите команду /start')
        elif len(values) < 3:
            raise ConvertionException('Слишком мало параметров или параметры введены неверно.\n'
                                      'Чтобы узнать правильные параметры ввода нажмите команду /start')

        quote, base, amount = values
        total_base = CryptoConverter.convert(quote, base, amount)
    except ConvertionException as e:
        bot.reply_to(message, f'Ошибка пользователя.\n{e}')
    except Exception as e:
        bot.reply_to(message, f'Не удалось обработать команду\n{e}')
    else:
        text = f'Цена {amount} {quote} в {base} - {total_base}'
        bot.send_message(message.chat.id, text)


@bot.message_handler(content_types=['voice'])
def voice_function(message):
    bot.send_message(message.chat.id, "А у тебя красивый голос")


@bot.message_handler(content_types=['sticker'])
def say_lmao(message: telebot.types.Message):
    bot.reply_to(message, f'Смешной стикер, {message.chat.first_name}')


@bot.message_handler(content_types=['photo'])
def text_handler(message):
    chat_id = message.chat.id
    bot.send_message(chat_id, 'Прикольно.')

@bot.message_handler(content_types=['video_note'])
def say_lmao(message: telebot.types.Message):
    bot.reply_to(message, f'Ура, я тебя вижу {message.chat.first_name}!))) ')


bot.polling(none_stop=True)
